# Init file for integrations package

from .knowledge_manager import KnowledgeManager

__all__ = ["KnowledgeManager"] 